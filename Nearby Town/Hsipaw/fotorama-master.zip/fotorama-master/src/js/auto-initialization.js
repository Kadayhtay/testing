$(function () {
  $('.' + _fotoramaClass + ':not([data-auto="false"])').fotorama();
});