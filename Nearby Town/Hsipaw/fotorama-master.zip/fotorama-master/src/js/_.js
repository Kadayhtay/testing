// My Underscore :-)
var _ = {};