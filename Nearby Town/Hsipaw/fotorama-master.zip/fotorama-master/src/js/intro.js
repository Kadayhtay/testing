(function (window, document, location, $, undefined) {
  "use strict";