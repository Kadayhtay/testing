})(window, document, location, typeof jQuery !== 'undefined' && jQuery);
